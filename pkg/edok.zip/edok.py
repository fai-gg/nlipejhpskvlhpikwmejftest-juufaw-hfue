#!/usr/bin/env python3
import os
import sys

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = 'hide'

sys.stdout = open(os.devnull, 'w')
sys.stderr = open(os.devnull, 'w')

import tkinter as tk
import pygame
from PIL import Image, ImageTk

# --- ตั้งค่าไฟล์และเวลา ---
IMAGE_PATH = "/teepkg/pkg/edok/edok.jpg"
AUDIO_PATH = "/teepkg/pkg/edok/edok.mp3"
DISPLAY_TIME_MS = 100
FADE_STEPS = 20
FADE_INTERVAL_MS = 30

try:
    pygame.mixer.init()
    pygame.mixer.music.load(AUDIO_PATH)
    pygame.mixer.music.play()
except Exception:
    pass

root = tk.Tk()
root.attributes('-fullscreen', True)
root.attributes('-topmost', True)
root.config(cursor="none")

screen_w = root.winfo_screenwidth()
screen_h = root.winfo_screenheight()

pil_img = Image.open(IMAGE_PATH)
pil_img = pil_img.resize((screen_w, screen_h), Image.Resampling.LANCZOS)
tk_img = ImageTk.PhotoImage(pil_img)

label = tk.Label(root, image=tk_img, bg='black')
label.pack(fill='both', expand=True)

def fade_out(alpha=1.0):
    if alpha > 0:
        alpha -= (1.0 / FADE_STEPS)
        root.attributes('-alpha', max(0.0, alpha))
        root.after(FADE_INTERVAL_MS, lambda: fade_out(alpha))
    else:
        root.destroy()
        sys.exit(0)

root.after(DISPLAY_TIME_MS, fade_out)

root.mainloop()
